"""
Report generation helpers for the assessment deliverables.

Produces:
- evaluation_report.json: metric definitions + raw scores + model summary + analysis
- FINAL_REPORT.md: single-page(ish) summary with prompt template and findings
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _utc_iso_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def build_model_summary(all_results: list[dict[str, Any]]) -> dict[str, Any]:
    models = sorted({r["model"] for r in all_results})
    summary: dict[str, Any] = {"models": {}}

    for model in models:
        rows = [r for r in all_results if r["model"] == model]
        if not rows:
            continue
        avg_fact = sum(r["fact_recall_score"] for r in rows) / len(rows)
        avg_tone = sum(r["tone_accuracy_score"] for r in rows) / len(rows)
        avg_ref_align = sum(r["reference_alignment_score"] for r in rows) / len(rows)
        overall = (avg_fact + avg_tone + avg_ref_align) / 3

        summary["models"][model] = {
            "avg_fact_recall_score": round(avg_fact, 4),
            "avg_tone_accuracy_score": round(avg_tone, 4),
            "avg_reference_alignment_score": round(avg_ref_align, 4),
            "overall_average_score": round(overall, 4),
            "num_scenarios": len(rows),
        }

    return summary


def build_comparative_analysis(all_results: list[dict[str, Any]]) -> dict[str, Any]:
    model_summary = build_model_summary(all_results)["models"]
    models = list(model_summary.keys())
    if len(models) < 2:
        return {"note": "Need at least 2 models for comparative analysis."}

    # Determine winner/loser by overall average.
    ranked = sorted(models, key=lambda m: model_summary[m]["overall_average_score"], reverse=True)
    winner, loser = ranked[0], ranked[-1]

    winner_s = model_summary[winner]
    loser_s = model_summary[loser]

    deltas = {
        "fact_recall": round(winner_s["avg_fact_recall_score"] - loser_s["avg_fact_recall_score"], 4),
        "tone_accuracy": round(winner_s["avg_tone_accuracy_score"] - loser_s["avg_tone_accuracy_score"], 4),
        "reference_alignment": round(
            winner_s["avg_reference_alignment_score"] - loser_s["avg_reference_alignment_score"], 4
        ),
    }
    biggest_gap_metric = max(deltas.items(), key=lambda kv: kv[1])[0]
    failure_mode_map = {
        "fact_recall": "Omitting/missing required key facts from the email.",
        "tone_accuracy": "Mismatching the requested tone.",
        "reference_alignment": "Lower alignment with the human reference email (structure/wording/content emphasis).",
    }

    # Worst scenario for the lower-performing model.
    loser_rows = [r for r in all_results if r["model"] == loser]
    worst = min(loser_rows, key=lambda r: r["scenario_average"]) if loser_rows else None

    return {
        "winner": winner,
        "loser": loser,
        "metric_gaps_winner_minus_loser": deltas,
        "biggest_gap_metric": biggest_gap_metric,
        "biggest_failure_mode": failure_mode_map.get(biggest_gap_metric, "Lower performance on one of the custom metrics."),
        "loser_worst_scenario": (
            {
                "scenario_id": worst["scenario_id"],
                "scenario_average": worst["scenario_average"],
                "fact_recall_score": worst["fact_recall_score"],
                "tone_accuracy_score": worst["tone_accuracy_score"],
                "reference_alignment_score": worst["reference_alignment_score"],
            }
            if worst
            else None
        ),
        "recommendation": {
            "recommended_model": winner,
            "reason": "Highest overall average score across the 3 custom metrics.",
        },
    }


def build_evaluation_report(
    *,
    all_results: list[dict[str, Any]],
    scenarios: list[dict[str, Any]],
    metric_definitions: dict[str, Any],
    prompt_template: str,
    model_a: str,
    model_b: str,
    judge_model: str,
) -> dict[str, Any]:
    summary = build_model_summary(all_results)
    analysis = build_comparative_analysis(all_results)

    return {
        "generated_at_utc": _utc_iso_now(),
        "models": {"model_a": model_a, "model_b": model_b, "judge_model": judge_model},
        "prompting_technique": {
            "name": "Role-Playing + Few-Shot Examples",
            "where": "prompt_template.py (SYSTEM_PROMPT)",
        },
        "prompt_template": prompt_template,
        "metrics": metric_definitions,
        "test_data": {"num_scenarios": len(scenarios), "scenarios": scenarios},
        "evaluation": {"num_rows": len(all_results), "rows": all_results},
        "summary": summary,
        "comparative_analysis": analysis,
    }


def write_json(path: str | Path, data: dict[str, Any]) -> str:
    import json

    out = Path(path)
    out.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return str(out)


def write_final_report_md(path: str | Path, report: dict[str, Any]) -> str:
    out = Path(path)
    models = report.get("summary", {}).get("models", {})
    analysis = report.get("comparative_analysis", {})
    metrics = report.get("metrics", {})
    prompt = report.get("prompt_template", "")

    lines: list[str] = []
    lines.append("# Final Report — Email Generation Assistant\n")
    lines.append("## Prompt Template (Advanced Prompt Engineering)\n")
    lines.append("Technique: Role-Playing + Few-Shot Examples\n")
    lines.append("```text")
    lines.extend(prompt.splitlines())
    lines.append("```\n")

    lines.append("## Custom Metrics (Definitions + Logic)\n")
    for key, meta in metrics.items():
        lines.append(f"### {meta.get('name', key)}\n")
        lines.append(f"- Type: {meta.get('type')}")
        lines.append(f"- Range: {meta.get('range')}")
        lines.append(f"- Logic: {meta.get('logic')}\n")

    lines.append("## Results Summary (Per Model)\n")
    if not models:
        lines.append("- No model summary available.\n")
    else:
        for model, s in models.items():
            lines.append(f"- {model}: overall={s['overall_average_score']}, "
                         f"fact={s['avg_fact_recall_score']}, "
                         f"tone={s['avg_tone_accuracy_score']}, "
                         f"ref_align={s['avg_reference_alignment_score']}")
        lines.append("")

    lines.append("## Comparative Analysis (Single-Page Summary)\n")
    if "winner" in analysis:
        lines.append(f"- Better model: {analysis['winner']}")
        lines.append(f"- Lower-performing model: {analysis['loser']}")
        lines.append(f"- Biggest gap metric: {analysis.get('biggest_gap_metric')}")
        if analysis.get("biggest_failure_mode"):
            lines.append(f"- Biggest failure mode (from data): {analysis['biggest_failure_mode']}")
        worst = analysis.get("loser_worst_scenario")
        if worst:
            lines.append(
                f"- Lower model worst scenario: id={worst['scenario_id']} "
                f"(avg={worst['scenario_average']}, fact={worst['fact_recall_score']}, "
                f"tone={worst['tone_accuracy_score']}, ref_align={worst['reference_alignment_score']})"
            )
        rec = analysis.get("recommendation", {})
        if rec.get("recommended_model"):
            lines.append(f"- Production recommendation: {rec['recommended_model']} ({rec.get('reason', '')})")
        lines.append("")
    else:
        lines.append(f"- {analysis.get('note', 'No comparative analysis available.')}\n")

    lines.append("## Raw Evaluation Data\n")
    lines.append("- `evaluation_results.csv` (scores)")
    lines.append("- `evaluation_report.json` (metrics definitions + full raw data + summary)\n")

    out.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")
    return str(out)
