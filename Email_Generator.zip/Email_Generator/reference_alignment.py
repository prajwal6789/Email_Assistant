"""
Reference-based metric for email generation evaluation.

Goal: measure how well the generated email aligns with a human reference email
without requiring identical wording.
"""

from __future__ import annotations

import re


_STOPWORDS = {
    "the",
    "and",
    "for",
    "that",
    "with",
    "from",
    "this",
    "will",
    "our",
    "your",
    "have",
    "been",
    "they",
    "their",
    "into",
    "also",
    "you",
    "we",
    "are",
    "was",
    "were",
    "but",
    "not",
    "can",
    "may",
    "please",
    "thank",
    "thanks",
    "dear",
    "hi",
    "hello",
    "regards",
    "best",
    "sincerely",
    "kind",
    "warm",
}


def _strip_placeholders(text: str) -> str:
    # Remove bracket placeholders like [Client Name], [Your Name]
    return re.sub(r"\[[^\]]+\]", "", text)


def _extract_subject(email_text: str) -> str:
    for line in email_text.splitlines():
        if re.match(r"^\s*subject\s*:", line, flags=re.IGNORECASE):
            return line.split(":", 1)[1].strip()
    return ""


def _tokenize(text: str) -> list[str]:
    text = _strip_placeholders(text).lower()
    # Keep words and numbers, drop punctuation
    tokens = re.findall(r"[a-z0-9]+", text)
    return [t for t in tokens if len(t) > 3 and t not in _STOPWORDS]


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _f1_overlap(generated: list[str], reference: list[str]) -> float:
    if not generated and not reference:
        return 1.0
    if not generated or not reference:
        return 0.0

    gen_set = set(generated)
    ref_set = set(reference)
    overlap = len(gen_set & ref_set)
    precision = overlap / len(gen_set) if gen_set else 0.0
    recall = overlap / len(ref_set) if ref_set else 0.0
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def reference_alignment_score(generated_email: str, reference_email: str) -> float:
    """
    Reference Alignment Score (0.0–1.0)

    Combines:
    - Subject keyword Jaccard similarity (30%)
    - Body content-word overlap F1 (70%)
    """
    gen_subject = _tokenize(_extract_subject(generated_email))
    ref_subject = _tokenize(_extract_subject(reference_email))
    subject_score = _jaccard(set(gen_subject), set(ref_subject))

    # Remove subject lines before body tokenization to avoid over-weighting.
    gen_body = re.sub(r"^\s*subject\s*:.*$", "", generated_email, flags=re.IGNORECASE | re.MULTILINE)
    ref_body = re.sub(r"^\s*subject\s*:.*$", "", reference_email, flags=re.IGNORECASE | re.MULTILINE)

    body_score = _f1_overlap(_tokenize(gen_body), _tokenize(ref_body))
    score = 0.3 * subject_score + 0.7 * body_score
    score = max(0.0, min(1.0, score))
    return round(score, 4)

