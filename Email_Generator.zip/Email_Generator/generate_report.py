"""
Generate the assignment deliverable reports from an existing evaluation run.

This avoids requiring API calls when you already have `evaluation_results.json`.
"""

import json
import csv
from pathlib import Path

from metrics import METRIC_DEFINITIONS
from prompt_template import SYSTEM_PROMPT
from reference_alignment import reference_alignment_score
from results import build_evaluation_report, write_final_report_md, write_json
from scenarios import scenarios


def main():
    results_path = Path("evaluation_results.json")
    if not results_path.exists():
        raise SystemExit("Missing evaluation_results.json. Run `python evaluate.py` first.")

    all_results = json.loads(results_path.read_text(encoding="utf-8"))

    # Upgrade older evaluation_results.json files that don't yet include reference-based scoring.
    ref_by_id = {s["id"]: s.get("reference_email", "") for s in scenarios}
    for row in all_results:
        sid = row.get("scenario_id")
        if "reference_alignment_score" not in row:
            row["reference_alignment_score"] = reference_alignment_score(
                row.get("generated_email", ""),
                ref_by_id.get(sid, ""),
            )
        # Ensure scenario_average matches the active 3 metrics.
        row["scenario_average"] = round(
            (row.get("fact_recall_score", 0.0) + row.get("tone_accuracy_score", 0.0) + row["reference_alignment_score"]) / 3,
            4,
        )

    # Write upgraded score files (so artifacts match the current 3 metrics even if the original run used older metrics).
    upgraded_json = Path("evaluation_results_upgraded.json")
    upgraded_csv = Path("evaluation_results_upgraded.csv")
    upgraded_json.write_text(json.dumps(all_results, indent=2, ensure_ascii=False), encoding="utf-8")

    csv_fields = [
        "model",
        "scenario_id",
        "intent",
        "tone",
        "fact_recall_score",
        "tone_accuracy_score",
        "reference_alignment_score",
        "scenario_average",
    ]
    with upgraded_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=csv_fields)
        writer.writeheader()
        for row in all_results:
            writer.writerow({k: row.get(k, "") for k in csv_fields})

    # Keep these consistent with evaluate.py defaults.
    model_a = "llama-3.3-70b-versatile"
    model_b = "llama-3.1-8b-instant"
    judge_model = "llama-3.3-70b-versatile"

    report = build_evaluation_report(
        all_results=all_results,
        scenarios=scenarios,
        metric_definitions=METRIC_DEFINITIONS,
        prompt_template=SYSTEM_PROMPT,
        model_a=model_a,
        model_b=model_b,
        judge_model=judge_model,
    )

    write_json("evaluation_report.json", report)
    write_final_report_md("FINAL_REPORT.md", report)
    print("Wrote: evaluation_report.json, FINAL_REPORT.md, evaluation_results_upgraded.json, evaluation_results_upgraded.csv")


if __name__ == "__main__":
    main()
