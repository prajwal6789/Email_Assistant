"""
Evaluation Script – Email Generation Assistant
===============================================
Runs 10 scenarios through two Groq Llama models and scores each generated
email on 3 custom metrics.

CUSTOM METRICS
--------------
1. Fact Recall Score  (automated, rule-based)
   Logic: For each key fact provided, check how many distinct keywords/phrases
   from that fact appear in the generated email. Score = facts_found / total_facts.
   Range: 0.0 – 1.0

2. Tone Accuracy Score  (LLM-as-a-Judge)
   Logic: Ask a Groq Llama judge model to rate (1-10) how well the generated
   email matches the requested tone. Normalised to 0.0–1.0.
   Range: 0.0 – 1.0

3. Reference Alignment Score  (automated, reference-based)
   Logic: Compare the generated email to the scenario's Human Reference Email.
   Range: 0.0 – 1.0
"""

import os
import re
import json
import csv
import time
from groq import Groq
from scenarios import scenarios
from generate_emails import generate_email
from prompt_template import SYSTEM_PROMPT
from results import build_evaluation_report, write_json, write_final_report_md
from metrics import METRIC_DEFINITIONS
from reference_alignment import reference_alignment_score


client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# Models to compare
MODEL_A = "llama-3.3-70b-versatile"   # Primary model
MODEL_B = "llama-3.1-8b-instant"            # Smaller / faster model for comparison

JUDGE_MODEL = "llama-3.3-70b-versatile"

# ------------------------------------------------------------------
# METRIC 1: Fact Recall Score (rule-based)
# ------------------------------------------------------------------
def fact_recall_score(generated_email: str, facts: list[str]) -> float:
    """
    For each fact, extract meaningful keywords (words > 3 chars, ignore stopwords).
    A fact is considered 'recalled' if at least 60% of its keywords appear in the email.
    Final score = recalled_facts / total_facts.
    """
    STOPWORDS = {"the", "and", "for", "that", "with", "from", "this", "will",
                 "our", "your", "have", "been", "they", "their", "into", "also"}

    email_lower = generated_email.lower()
    recalled = 0

    for fact in facts:
        # Extract keywords from the fact
        words = re.findall(r"[a-zA-Z0-9#$%]+", fact.lower())
        keywords = [w for w in words if len(w) > 3 and w not in STOPWORDS]

        if not keywords:
            recalled += 1  # trivial fact, count it
            continue

        hits = sum(1 for kw in keywords if kw in email_lower)
        if hits / len(keywords) >= 0.6:
            recalled += 1

    return round(recalled / len(facts), 4) if facts else 0.0


# ------------------------------------------------------------------
# METRIC 2: Tone Accuracy Score (LLM-as-a-Judge)
# ------------------------------------------------------------------
def tone_accuracy_score(generated_email: str, requested_tone: str) -> float:
    """
    Ask the judge model to rate tone match on a scale of 1-10.
    Returns normalised score 0.0–1.0.
    """
    prompt = f"""You are an expert email evaluator. Rate the following email on how well it matches the requested tone.

Requested tone: "{requested_tone}"

Email:
\"\"\"
{generated_email}
\"\"\"

Give a single integer score from 1 (completely wrong tone) to 10 (perfect tone match).
Respond with ONLY the integer, nothing else."""

    try:
        response = client.chat.completions.create(
            model=JUDGE_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0,
            max_tokens=5
        )
        raw = response.choices[0].message.content.strip()
        score = int(re.search(r"\d+", raw).group())
        score = max(1, min(10, score))
        return round(score / 10, 4)
    except Exception as e:
        print(f"  [WARN] Tone judge failed: {e}")
        return 0.5



# ------------------------------------------------------------------
# Run evaluation for one model
# ------------------------------------------------------------------
def evaluate_model(model_name: str, scenarios: list) -> list[dict]:
    results = []
    print(f"\n{'='*60}")
    print(f"Evaluating Model: {model_name}")
    print(f"{'='*60}")

    for s in scenarios:
        print(f"\n  Scenario {s['id']}: {s['intent'][:50]}...")

        # Generate email
        try:
            email = generate_email(s["intent"], s["facts"], s["tone"], model=model_name)
        except Exception as e:
            print(f"  [ERROR] Generation failed: {e}")
            email = ""

        # Score it
        m1 = fact_recall_score(email, s["facts"])
        print(f"    Metric 1 (Fact Recall)       : {m1}")

        time.sleep(0.5)  # avoid rate limiting
        m2 = tone_accuracy_score(email, s["tone"])
        print(f"    Metric 2 (Tone Accuracy)     : {m2}")

        m3 = reference_alignment_score(email, s.get("reference_email", ""))
        print(f"    Metric 3 (Ref. Alignment)    : {m3}")

        avg = round((m1 + m2 + m3) / 3, 4)
        print(f"    Overall Average              : {avg}")

        results.append({
            "model": model_name,
            "scenario_id": s["id"],
            "intent": s["intent"],
            "tone": s["tone"],
            "fact_recall_score": m1,
            "tone_accuracy_score": m2,
            "reference_alignment_score": m3,
            "scenario_average": avg,
            "generated_email": email
        })

        time.sleep(1.0)  # be nice to the API

    return results


# ------------------------------------------------------------------
# Save results
# ------------------------------------------------------------------
def save_results(all_results: list[dict]):
    # CSV (without the email text for readability)
    csv_path = "evaluation_results.csv"
    csv_fields = ["model", "scenario_id", "intent", "tone",
                  "fact_recall_score", "tone_accuracy_score",
                  "reference_alignment_score", "scenario_average"]

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=csv_fields)
        writer.writeheader()
        for row in all_results:
            writer.writerow({k: row[k] for k in csv_fields})

    # JSON (full, including generated emails)
    json_path = "evaluation_results.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)

    print(f"\nResults saved to: {csv_path} and {json_path}")
    return csv_path, json_path


def save_structured_report(all_results: list[dict]):
    """
    Writes the assignment-aligned structured report file and a one-page summary.

    - evaluation_report.json includes:
      - prompt template
      - metric definitions + logic
      - test scenarios (with human reference emails)
      - raw evaluation rows + model-level summary + comparative analysis
    - FINAL_REPORT.md is a short summary derived from evaluation_report.json.
    """
    report = build_evaluation_report(
        all_results=all_results,
        scenarios=scenarios,
        metric_definitions=METRIC_DEFINITIONS,
        prompt_template=SYSTEM_PROMPT,
        model_a=MODEL_A,
        model_b=MODEL_B,
        judge_model=JUDGE_MODEL,
    )

    report_json_path = write_json("evaluation_report.json", report)
    report_md_path = write_final_report_md("FINAL_REPORT.md", report)
    print(f"Structured report saved to: {report_json_path}")
    print(f"Final report saved to: {report_md_path}")
    return report_json_path, report_md_path


# ------------------------------------------------------------------
# Summary
# ------------------------------------------------------------------
def print_summary(all_results: list[dict]):
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")

    for model in [MODEL_A, MODEL_B]:
        rows = [r for r in all_results if r["model"] == model]
        if not rows:
            continue
        avg_m1 = round(sum(r["fact_recall_score"] for r in rows) / len(rows), 4)
        avg_m2 = round(sum(r["tone_accuracy_score"] for r in rows) / len(rows), 4)
        avg_m3 = round(sum(r["reference_alignment_score"] for r in rows) / len(rows), 4)
        overall = round((avg_m1 + avg_m2 + avg_m3) / 3, 4)

        print(f"\nModel: {model}")
        print(f"  Avg Fact Recall Score          : {avg_m1}")
        print(f"  Avg Tone Accuracy Score        : {avg_m2}")
        print(f"  Avg Reference Alignment Score  : {avg_m3}")
        print(f"  Overall Average Score          : {overall}")


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
if __name__ == "__main__":
    all_results = []

    results_a = evaluate_model(MODEL_A, scenarios)
    all_results.extend(results_a)

    results_b = evaluate_model(MODEL_B, scenarios)
    all_results.extend(results_b)

    save_results(all_results)
    save_structured_report(all_results)
    print_summary(all_results)
