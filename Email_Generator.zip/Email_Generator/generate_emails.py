"""
Email Generation Assistant
Uses Groq Cloud's Llama model with Few-Shot prompting technique.

Advanced Prompting Technique: FEW-SHOT + ROLE-PLAYING
- The model is given a role (senior business communication expert)
- Two worked examples are provided before the actual task
- This anchors the model's output style, structure, and quality
"""

import os
from groq import Groq
from dotenv import load_dotenv
from prompt_template import SYSTEM_PROMPT

load_dotenv()

client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

# System prompt is centralized in prompt_template.py for consistency.



def generate_email(intent: str, facts: list[str], tone: str, model: str = "llama-3.3-70b-versatile") -> str:
    """Generate a professional email using the Groq Llama model."""
    facts_str = "\n".join(f"- {f}" for f in facts)
    user_prompt = f"""Intent: {intent}
Key Facts:
{facts_str}
Tone: {tone}"""

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.4,
        max_tokens=600
    )
    return response.choices[0].message.content.strip()


if __name__ == "__main__":
    # Quick demo
    print("=== Email Generation Assistant (Groq Llama) ===\n")
    intent = "Follow up after a business meeting"
    facts = [
        "Meeting was held on July 10th",
        "Discussed Q3 marketing budget of $50,000",
        "Next steps: share proposal by July 17th",
        "Attendees: Sarah (client), John (our side)"
    ]
    tone = "formal"

    print(f"Intent : {intent}")
    print(f"Tone   : {tone}")
    print(f"Facts  : {facts}\n")
    print("--- Generated Email ---")
    email = generate_email(intent, facts, tone)
    print(email)
