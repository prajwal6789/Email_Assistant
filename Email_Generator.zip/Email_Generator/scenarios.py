scenarios = [
    {
        "id": 1,
        "intent": "Follow up after a business meeting",
        "facts": [
            "Meeting was held on July 10th",
            "Discussed Q3 marketing budget of $50,000",
            "Next steps: share proposal by July 17th",
            "Attendees: Sarah (client), John (our side)"
        ],
        "tone": "formal",
        "reference_email": """Subject: Follow-Up: Q3 Marketing Budget Discussion – July 10th Meeting

Dear Sarah,

Thank you for taking the time to meet with us on July 10th. It was a productive discussion, and I wanted to follow up on the key points we covered.

As discussed, we went over the Q3 marketing budget of $50,000 and explored how it can be allocated most effectively. Per our conversation, the next step is for our team to prepare and share a detailed proposal with you by July 17th.

John and I are already working on the proposal and will ensure it reflects everything we discussed. Please don't hesitate to reach out if you have any questions or additional input before then.

Looking forward to your feedback.

Best regards,
John"""
    },
    {
        "id": 2,
        "intent": "Request for project proposal details from a vendor",
        "facts": [
            "Vendor name: TechBuild Solutions",
            "Project: CRM system upgrade",
            "Deadline for proposal: August 5th",
            "Need pricing, timeline, and team details"
        ],
        "tone": "formal",
        "reference_email": """Subject: Request for Proposal – CRM System Upgrade

Dear TechBuild Solutions Team,

I hope this message finds you well. We are currently evaluating vendors for an upcoming CRM system upgrade and would like to formally request a detailed proposal from your team.

Specifically, we require the following information:
- Proposed pricing for the project
- Estimated timeline for delivery
- Details of the team that would be assigned to this engagement

We kindly ask that you submit your proposal no later than August 5th so we can proceed with our evaluation process in a timely manner.

Please feel free to reach out if you have any clarifying questions. We look forward to reviewing your submission.

Sincerely,
Procurement Team"""
    },
    {
        "id": 3,
        "intent": "Apologize for a delayed product delivery",
        "facts": [
            "Order number: #4521",
            "Original delivery date: June 28th",
            "New estimated delivery: July 5th",
            "Delay caused by supply chain disruption",
            "Offering 10% discount on next order"
        ],
        "tone": "empathetic",
        "reference_email": """Subject: Important Update Regarding Your Order #4521

Dear Valued Customer,

I sincerely apologize for the inconvenience caused by the delay in your order #4521. We understand how frustrating this must be, and I want to personally address the situation.

Due to an unexpected supply chain disruption, we were unable to meet our original delivery date of June 28th. We are now working diligently to ensure your order reaches you by July 5th.

As a token of our appreciation for your patience, we would like to offer you a 10% discount on your next order with us. Your satisfaction is our top priority, and we are committed to making this right.

Thank you for your understanding, and please don't hesitate to contact us if you have any questions.

Warm regards,
Customer Support Team"""
    },
    {
        "id": 4,
        "intent": "Invite a speaker to a company event",
        "facts": [
            "Event: Annual Tech Summit 2025",
            "Date: September 15th",
            "Location: Bangalore Convention Centre",
            "Topic: AI in Healthcare",
            "Honorarium: INR 25,000"
        ],
        "tone": "formal",
        "reference_email": """Subject: Speaking Invitation – Annual Tech Summit 2025

Dear [Speaker Name],

On behalf of our organizing committee, I am delighted to invite you to speak at our Annual Tech Summit 2025, scheduled for September 15th at the Bangalore Convention Centre.

Given your remarkable expertise in the field, we believe you would be an exceptional speaker on the topic of "AI in Healthcare." Your insights would greatly enrich the experience for our attendees.

We are pleased to offer an honorarium of INR 25,000 for your participation. Our team will also handle all logistical arrangements to ensure a seamless experience for you.

We would be honored to have you join us and kindly request your confirmation at your earliest convenience.

Warm regards,
Event Organizing Committee"""
    },
    {
        "id": 5,
        "intent": "Notify team about a policy change",
        "facts": [
            "New policy: Mandatory two-factor authentication",
            "Effective date: August 1st",
            "IT team will send setup instructions",
            "Non-compliance may result in access revocation"
        ],
        "tone": "urgent",
        "reference_email": """Subject: URGENT: Mandatory Two-Factor Authentication – Effective August 1st

Dear Team,

This is an important notice regarding a critical update to our security policy.

Effective August 1st, two-factor authentication (2FA) will be mandatory for all employees accessing company systems. This measure is being implemented to strengthen our data security and protect sensitive information.

The IT team will be sending detailed setup instructions shortly. Please ensure you complete the setup before the deadline.

Please be aware that failure to comply by August 1st may result in the temporary revocation of your system access. We urge you to prioritize this action immediately.

If you encounter any issues during the setup process, please contact the IT helpdesk as soon as possible.

Thank you for your prompt attention to this matter.

Regards,
IT Security Team"""
    },
    {
        "id": 6,
        "intent": "Thank a client after successful project completion",
        "facts": [
            "Project: Website redesign for RetailMax",
            "Completed 2 weeks ahead of schedule",
            "Client expressed high satisfaction",
            "Looking forward to future collaboration"
        ],
        "tone": "warm and professional",
        "reference_email": """Subject: Thank You – Successful Completion of RetailMax Website Redesign

Dear RetailMax Team,

It has been an absolute pleasure working with you on the website redesign project. We are thrilled to share that the project was completed two weeks ahead of schedule, a testament to the excellent collaboration between our teams.

Your positive feedback means a great deal to us, and knowing that you are satisfied with the outcome makes all the effort worthwhile. We take immense pride in delivering work that exceeds expectations.

We genuinely look forward to the opportunity of working together again in the future. Please know that our team is always here should you need any support or have new projects in mind.

Thank you once again for placing your trust in us.

Warm regards,
Project Delivery Team"""
    },
    {
        "id": 7,
        "intent": "Request a meeting with a potential investor",
        "facts": [
            "Startup name: GreenPath Technologies",
            "Sector: Renewable Energy",
            "Seeking: $500,000 seed funding",
            "Preferred meeting: virtual, 30 minutes",
            "Available: any weekday next week"
        ],
        "tone": "confident and professional",
        "reference_email": """Subject: Meeting Request – GreenPath Technologies Seed Funding Discussion

Dear [Investor Name],

I hope you are doing well. My name is [Your Name], and I am the founder of GreenPath Technologies, an early-stage startup in the renewable energy sector.

We are currently seeking $500,000 in seed funding to accelerate our growth and bring our solutions to market. Having followed your investment portfolio closely, I believe there is a strong alignment between your interests and our vision.

I would love the opportunity to connect for a brief 30-minute virtual meeting at your convenience. I am available any weekday next week and am happy to work around your schedule.

I look forward to the possibility of exploring this opportunity together.

Best regards,
[Your Name]
Founder, GreenPath Technologies"""
    },
    {
        "id": 8,
        "intent": "Decline a job applicant politely",
        "facts": [
            "Applicant name: Ravi Kumar",
            "Position applied for: Senior Data Scientist",
            "Strong applicant but position filled internally",
            "Encourage to apply for future roles"
        ],
        "tone": "empathetic and professional",
        "reference_email": """Subject: Your Application for Senior Data Scientist – GreenPath Technologies

Dear Ravi,

Thank you sincerely for taking the time to apply for the Senior Data Scientist position and for the interest you have shown in joining our team.

After careful consideration, we have decided to move forward with an internal candidate for this particular role. This was a genuinely difficult decision, as we were impressed by your background and the experience you brought to the table.

We would like to encourage you to keep an eye on our future openings, as we would welcome the opportunity to consider your profile again. Your skills are certainly valuable, and we hope our paths cross again.

We wish you all the best in your job search and future endeavors.

Kind regards,
HR Team"""
    },
    {
        "id": 9,
        "intent": "Send a project status update to stakeholders",
        "facts": [
            "Project: ERP Implementation Phase 2",
            "Current status: 65% complete",
            "Milestone achieved: Data migration done",
            "Next milestone: User Acceptance Testing by August 20th",
            "No budget overruns so far"
        ],
        "tone": "formal",
        "reference_email": """Subject: Project Status Update – ERP Implementation Phase 2

Dear Stakeholders,

I am writing to provide you with the latest status update on the ERP Implementation Phase 2 project.

We are pleased to report that the project is currently 65% complete and progressing as planned. A key milestone was achieved recently with the successful completion of data migration, which keeps us firmly on track.

Our next major milestone is User Acceptance Testing, which is scheduled to commence by August 20th. We are actively preparing for this phase to ensure it proceeds smoothly.

On the financial front, we are happy to confirm that there are no budget overruns at this stage. We remain committed to delivering the project within the approved budget and timeline.

We will continue to keep you informed as the project progresses. Please feel free to reach out if you have any questions.

Best regards,
Project Manager"""
    },
    {
        "id": 10,
        "intent": "Congratulate a colleague on a promotion",
        "facts": [
            "Colleague name: Priya Sharma",
            "Promoted to: Head of Product",
            "Has been with the company for 5 years",
            "Known for launching the mobile app successfully"
        ],
        "tone": "casual and warm",
        "reference_email": """Subject: Congratulations on Your Well-Deserved Promotion, Priya!

Hi Priya,

Huge congratulations on your promotion to Head of Product! This is such exciting news, and honestly, no one deserves it more than you.

Five years of incredible dedication, and what a journey it has been! Watching you lead the mobile app launch was truly inspiring — that project alone spoke volumes about your vision and your ability to get things done.

I have no doubt you are going to absolutely thrive in this new role. The product team is lucky to have you at the helm.

Wishing you all the very best as you step into this exciting new chapter!

Cheers,
[Your Name]"""
    }
]