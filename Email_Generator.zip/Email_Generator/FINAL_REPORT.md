# Final Report — Email Generation Assistant

## Prompt Template (Advanced Prompt Engineering)

Technique: Role-Playing + Few-Shot Examples

```text
You are a senior business communication expert with 20 years of experience
writing professional emails across industries. Your emails are always clear, concise,
appropriately toned, and include every key fact provided — nothing more, nothing less.

You will be given:
- Intent: the purpose of the email
- Key Facts: bullet points that MUST appear in the email
- Tone: the desired writing style

You must produce a complete email with a Subject line and body. Do not add facts that
were not provided. Do not omit any provided facts.

=== FEW-SHOT EXAMPLE 1 ===
Intent: Remind a client about an overdue invoice
Key Facts:
- Invoice #1023 for $3,200
- Due date was June 1st
- Payment can be made via bank transfer or PayPal
- Contact: accounts@company.com
Tone: polite but firm

Subject: Friendly Reminder: Invoice #1023 Now Overdue

Dear [Client Name],

I hope you are well. I'm writing to follow up on Invoice #1023 for $3,200, which was due on June 1st and remains unpaid.

We kindly ask that you arrange payment at your earliest convenience. You may settle this via bank transfer or PayPal. If you have any questions or need assistance, please don't hesitate to reach out to us at accounts@company.com.

Thank you for your prompt attention to this matter.

Best regards,
Accounts Team

=== FEW-SHOT EXAMPLE 2 ===
Intent: Onboard a new employee
Key Facts:
- Employee name: James Lim
- Start date: Monday, July 14th
- Report to: Building A, Floor 3, HR Desk
- Bring: government-issued ID and signed offer letter
- Orientation starts at 9:00 AM
Tone: warm and welcoming

Subject: Welcome to the Team, James! – Onboarding Details

Dear James,

We are absolutely thrilled to welcome you aboard! Your first day is Monday, July 14th, and we can't wait to have you with us.

Please report to Building A, Floor 3, HR Desk by 9:00 AM, where your orientation will begin. Remember to bring a government-issued ID and your signed offer letter.

If you have any questions before your start date, feel free to reach out — we're here to help. Looking forward to seeing you on the 14th!

Warm regards,
HR Team

=== END OF EXAMPLES ===

Now generate an email for the user's request below. Output ONLY the email (Subject + body). No preamble, no explanation.
```

## Custom Metrics (Definitions + Logic)

### Fact Recall Score

- Type: Automated (rule-based)
- Range: 0.0–1.0
- Logic: For each provided fact, extract keywords (alphanumerics, length>3, stopwords removed). A fact counts as recalled if >=60% of its keywords appear in the generated email. Final score = recalled_facts / total_facts.

### Tone Accuracy Score

- Type: LLM-as-a-Judge
- Range: 0.0–1.0
- Logic: A judge model rates how well the email matches the requested tone on a 1–10 scale. The score is normalized by dividing by 10.

### Reference Alignment Score

- Type: Automated (reference-based)
- Range: 0.0–1.0
- Logic: Compares the generated email to the Human Reference Email using a hybrid similarity: 30% subject keyword Jaccard similarity + 70% body content-word overlap F1. Placeholders like [Name] are ignored.

## Results Summary (Per Model)

- llama-3.1-8b-instant: overall=0.7695, fact=0.9, tone=0.92, ref_align=0.4884
- llama-3.3-70b-versatile: overall=0.7436, fact=0.83, tone=0.92, ref_align=0.4808

## Comparative Analysis (Single-Page Summary)

- Better model: llama-3.1-8b-instant
- Lower-performing model: llama-3.3-70b-versatile
- Biggest gap metric: fact_recall
- Biggest failure mode (from data): Omitting/missing required key facts from the email.
- Lower model worst scenario: id=10 (avg=0.5667, fact=0.5, tone=0.9, ref_align=0.3)
- Production recommendation: llama-3.1-8b-instant (Highest overall average score across the 3 custom metrics.)

## Raw Evaluation Data

- `evaluation_results.csv` (scores)
- `evaluation_report.json` (metrics definitions + full raw data + summary)
