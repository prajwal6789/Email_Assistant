"""
Metric definitions and logic (for structured reporting).

The actual implementations live in evaluate.py; this module exists so that
both evaluation and report generation can share the same definitions.
"""

METRIC_DEFINITIONS = {
    "fact_recall_score": {
        "name": "Fact Recall Score",
        "type": "Automated (rule-based)",
        "range": "0.0–1.0",
        "logic": (
            "For each provided fact, extract keywords (alphanumerics, length>3, stopwords removed). "
            "A fact counts as recalled if >=60% of its keywords appear in the generated email. "
            "Final score = recalled_facts / total_facts."
        ),
    },
    "tone_accuracy_score": {
        "name": "Tone Accuracy Score",
        "type": "LLM-as-a-Judge",
        "range": "0.0–1.0",
        "logic": (
            "A judge model rates how well the email matches the requested tone on a 1–10 scale. "
            "The score is normalized by dividing by 10."
        ),
    },
    "reference_alignment_score": {
        "name": "Reference Alignment Score",
        "type": "Automated (reference-based)",
        "range": "0.0–1.0",
        "logic": (
            "Compares the generated email to the Human Reference Email using a hybrid similarity: "
            "30% subject keyword Jaccard similarity + 70% body content-word overlap F1. "
            "Placeholders like [Name] are ignored."
        ),
    },
}
